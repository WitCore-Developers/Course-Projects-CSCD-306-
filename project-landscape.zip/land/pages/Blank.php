<!DOCTYPE html>
<html>
<head>
  <title>PetMart</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
 <!-- Material Design Bootstrap -->
<link rel="stylesheet" href="assets/mdb/css/mdb.min.css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!--<link href="assets/css/style.css" rel="stylesheet" type="text/css"> -->
<script src="https://kit.fontawesome.com/b791fdaf68.js" crossorigin="anonymous"></script>
</head>
<body>
 
</body>
<script type="text/javascript" src="../assets/mdb/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../assets/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../assets/mdb/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../assets/mdb/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
  <script>
      feather.replace()
    </script>
</html>