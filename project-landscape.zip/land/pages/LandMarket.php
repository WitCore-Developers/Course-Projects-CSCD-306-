<!DOCTYPE html>
<html>
<head>
  <title>LandMarket</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
<!-- the bootstrap css of the page -->
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
 <!-- Material Design Bootstrap -->
<link rel="stylesheet" href="../assets/mdb/css/mdb.min.css">
<link href="../assets/css/styles.css" rel="stylesheet" type="text/css">
<!--<link href="assets/css/style.css" rel="stylesheet" type="text/css"> -->
<script src="https://kit.fontawesome.com/b791fdaf68.js" crossorigin="anonymous"></script>
</head>
<body>
 <!--Navbar -->
<nav class="mb-1 navbar navbar-expand-lg navbar-dark bg-info sticky-top">
  <a class="navbar-brand font-weight-bold" href="#">LandScape</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
    aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="../index.php">Home
          <span class="sr-only">(current)</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Land Market</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>
      <li class="nav-item dropdown">
        
        <div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto nav-flex-icons">
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light">
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light">
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-default"
          aria-labelledby="navbarDropdownMenuLink-333">
          <a class="dropdown-item" href="#">Login</a>
          <a class="dropdown-item" href="#">Sign Up</a>
        </div>
      </li>
    </ul>
  </div>
</nav>
<!--/.Navbar -->
  <!-- SideNav pushed content -->
  <a href="#" data-activates="slide-out" class="btn-floating btn-info button-collapse btn-lg"><i
    class="fas fa-bars"></i></a>

  <!-- Sidebar navigation -->
  <div id="slide-out" class="side-nav fixed bg-info">
    <ul class="custom-scrollbar">
      
      <!--/. Side navigation links -->
    </ul>
  </div>
  <!--/. Sidebar navigation -->
  <div id="content" class="content">
    <header>
      <h1 class="display-4 font-weight-bold text-center text-info main-header">LAND MARKET</h1>
      <div class="md-form active-cyan active-cyan-2 mb-3">
  <input class="form-control" type="text" placeholder="Search" aria-label="Search">
</div>

      <blockquote class="blockquote bq-info">
        <p class="bq-title font-weight-bold">Land Deals</p>
      </blockquote>
      <hr>
    </header>
    <section>
      <!--starting of land body-->
<div class="container-fluid">
  <div class="row">
     <!--first 3 rows-->
     <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
 <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
           
       <!--end of first 3 rows-->
        <!--second 3 rows-->
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
 <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
       <!--end of second 3 rows-->
        <!--third 3 rows-->
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
 <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
       <!--end of third 3 rows-->
        <!--fourth 3 rows-->
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
 <div class="col-md-4 mb-4">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="https://mdbootstrap.com/img/Photos/Horizontal/Nature/4-col/img%20(34).jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
       <!--end of fourth 3 rows-->
    </div>
  </div>
  <!--End of land body-->   
    </section>
  </div>
  <!-- Footer -->
<footer class="page-footer font-small py-2 bg-info white-text">

  <!-- Footer Elements -->
  <div class="container">

    <div class="row">
      <div class="col-md-4">
        <h3 class="font-weight-bold mb-0">LandScape</h3>
      </div>
      <div class="col-md-4">
        <ul class="list-unstyled d-flex justify-content-center mb-0 mt-2 text-uppercase">
          <li>
            <a class="mx-3" role="button">About</a>
          </li>
          <li>
            <a class="mx-3" role="button">Blog</a>
          </li>
          <li>
            <a class="mx-3" role="button">Policy</a>
          </li>
          <li>
            <a class="mx-3" role="button">Contact</a>
          </li>
        </ul>
      </div>
      <div class="col-md-4">
        <ul class="list-unstyled d-flex justify-content-end mb-0 mt-2">
          <li>
            <a class="mx-3" role="button"><i class="fab fa-facebook-f"></i></a>
          </li>
          <li>
            <a class="mx-3" role="button"><i class="fab fa-twitter"></i></a>
          </li>
          <li>
            <a class="mx-3" role="button"><i class="fab fa-instagram"></i></a>
          </li>
        </ul>
      </div>
      
    </div>

  </div>
  <!-- Footer Elements -->

</footer>
<!-- Footer -->
</body>
<script type="text/javascript" src="../assets/mdb/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="../assets/bootstrap/js/jquery.js">
  <script type="text/javascript" src="../assets/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="../assets/mdb/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="../assets/bootstrap/js/bootstrap.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="../assets/mdb/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript">
    $(document).ready(function() {
  let isOpen = false;
  let $windowWidth = $( window ).width();
  const $btnCollapse = $(".button-collapse");
  const $content = $('#content');
  
  $( window ).resize(function() { 

    $windowWidth = $( window ).width(); 
    if($windowWidth > 1440) {
      $content.css('padding-left', '250px');
      if(isOpen) {
        $btnCollapse.css('left', '0');
        isOpen = false; 
      }
    } else if($windowWidth < 530 && isOpen) {
      $btnCollapse.css('left', '0');
      $content.css('padding-left', '0');
      $('#sidenav-overlay').css('display', 'block'); 
      $btnCollapse.trigger('click');
    } else {
      if(!isOpen) {
        $content.css('padding-left', '0'); 
      }
    }
  });
  
  // SideNav Button Initialization
  $btnCollapse.sideNav(); 
  
  $btnCollapse.on('click', () => { 
   isOpen = !isOpen;
   if($windowWidth > 530) {
    const elPadding = isOpen ? '250px' : '0';
    $btnCollapse.css('left', elPadding);
    $content.css('padding-left', elPadding);
    $('#sidenav-overlay').css('display', 'none');
   } else {
    $('#sidenav-overlay').on('click', () => {
      isOpen = !isOpen;
    });
   }      
  }); 
  $('#sidenav-overlay').on('click', () => {
      isOpen = !isOpen;
    });
});
  </script>
  <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
  <script>
      feather.replace()
    </script>
</html>