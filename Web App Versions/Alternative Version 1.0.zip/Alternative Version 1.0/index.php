<!DOCTYPE html>
<html>
<head>
  <title>LandScape</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- the bootstrap css of the page -->
<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
 <!-- Material Design Bootstrap -->
 <link href="assets/mdb/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="assets/mdb/css/mdb.min.css">
<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
<!--<link href="assets/css/style.css" rel="stylesheet" type="text/css"> -->
<script src="https://kit.fontawesome.com/b791fdaf68.js" crossorigin="anonymous"></script>
</head>
<body>
 <!--Navbar -->
<nav class="mb-1 navbar navbar-expand-lg navbar-dark bg-info sticky-top">
  <a class="navbar-brand font-weight-bold" href="#">LandScape</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333"
    aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent-333">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home
          <span class="sr-only">(current)</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="pages/LandMarket.php">Land Market</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>
      <li class="nav-item dropdown">
        
        <div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
    </ul>
    <ul class="navbar-nav ml-auto nav-flex-icons">
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light">
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light">
        </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right dropdown-default"
          aria-labelledby="navbarDropdownMenuLink-333">
          <a class="dropdown-item" href="#">Login</a>
          <a class="dropdown-item" href="#">Sign Up</a>
        </div>
      </li>
    </ul>
  </div>
</nav>
<!--/.Navbar -->
<section class="land-background-image text-center">
  <h1 class=" land-background-text display-4 text-center text-info main-header font-weight-bold">Welcome<span class="text-white"> to Our Land Site</span></h1>
<h3 class="h3-responsive text-white font-weight-bold">The Best Place to Find the <span class="text-info">Land you want</span></h3>
</section>

<!--search bar-->
<div class="search-bar container-fluid p-0">
<form>
   <input class="z-depth-2" type="text" placeholder="Search for Lands in all locations" name="Search" required="">
  <input class="bg-info z-depth-2" type="submit" value="Find">
</form>
</div>
<!-- end of search bar-->
<section class="land-carousel">
<!--start of land carousel-->
<!-- Carousel Wrapper -->
    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">
      <!-- Controls -->
      <div class="controls-top">
        <a class="btn-floating info-color waves-effect waves-light" href="#multi-item-example" data-slide="prev">
          <i class="fas fa-chevron-left"></i>
        </a>
        <a class="btn-floating info-color waves-effect waves-light" href="#multi-item-example" data-slide="next">
          <i class="fas fa-chevron-right"></i>
        </a>
      </div>
      <!-- Controls -->
      <!-- Indicators -->
      <ol class="carousel-indicators mb-n3">
        <li class="info-color active" data-target="#multi-item-example" data-slide-to="0"></li>
        <li class="info-color" data-target="#multi-item-example" data-slide-to="1"></li>
        <li class="info-color" data-target="#multi-item-example" data-slide-to="2"></li>
      </ol>
      <!-- Indicators -->
      <!-- Slides -->
      <div class="carousel-inner" role="listbox">
        <!-- First slide -->
        <div class="carousel-item active">
         <div class="col-md-4 mb-2">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/land-site.PNG"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/carousel-1.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1"
            src="assets/images/carousel-2.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
        </div>
        <!-- End of First slide -->
        <!-- Second slide -->
        <div class="carousel-item">
          <div class="col-md-4 mb-2">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/carousel.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/carousel-1.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
           <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/land-site.PNG"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
          </div>
        <!-- Second slide -->
        <!--Third slide -->
        <div class="carousel-item">
          <div class="col-md-4 mb-2">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/carousel-1.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
      <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/carousel-2.jpg"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
           <div class="col-md-4 mb-2 clearfix d-none d-md-block">
          <div class="card mb-2 card-border border border-white z-depth-2">
          <img class="card-img-top land-image z-depth-1 img-fluid"
            src="assets/images/land-site.PNG"
            alt="Card image cap">
          <div class="row">
          <div class="col-6">
            <div class="land-content-1">
             <p><i class="fas fa-money-bill-alt"></i><strong>GHC 200.000</strong></p>
            <p><i class="fas fa-map-marker-alt"></i><small class="font-weight-lighter">Airport Hills,Accra</small></p>
            </div>
          </div>
          <div class="col-6">
            <div class="land-content-2">
            <p class="text-right"><small class="font-weight-lighter">40 Acres</small></p>
            <p class="text-right"><small class="font-weight-lighter">Commercial</small></p>
            </div>
         </div>
         </div>
        </div>
      </div>
          </div>
        </div>
        <!--Third slide -->
      </div>
    </div>
      <!-- Slides -->
    </div>
    <!-- Carousel Wrapper -->
<!--end of land carousel-->
</section>
<section>
  <div class="container">


  <!--Section: Content-->
  <section class="">

    <div class="row pr-lg-5">
      <div class="col-md-7 mb-4">

        <div class="view">
          <img src="assets/images/land.png" class="img-fluid" alt="smaple image">
        </div>

      </div>
      <div class="col-md-5 d-flex align-items-center">
        <div>
          
          <h3 class="font-weight-bold mb-4 text-info">We are Offering The Best Land Deals</h3>

          <p>Lorem ipsum dolor sit amet consectetur adip elit. Maiores deleniti explicabo voluptatem quisquam nulla asperiores aspernatur aperiam voluptate et consectetur minima delectus, fugiat eum soluta blanditiis adipisci, velit dolore magnam.</p>

          <button type="button" class="btn btn-info btn-rounded mx-0">Check out Deals</button>

        </div>
      </div>
    </div>

  </section>
  <!--Section: Content-->

</div>
</section>
<!-- Footer -->
<footer class="page-footer font-small py-2 bg-info white-text">

  <!-- Footer Elements -->
  <div class="container">

    <div class="row">
      <div class="col-md-4">
        <h3 class="font-weight-bold mb-0">LandScape</h3>
      </div>
      <div class="col-md-4">
        <ul class="list-unstyled d-flex justify-content-center mb-0 mt-2 text-uppercase">
          <li>
            <a class="mx-3" role="button">About</a>
          </li>
          <li>
            <a class="mx-3" role="button">Blog</a>
          </li>
          <li>
            <a class="mx-3" role="button">Policy</a>
          </li>
          <li>
            <a class="mx-3" role="button">Contact</a>
          </li>
        </ul>
      </div>
      <div class="col-md-4">
        <ul class="list-unstyled d-flex justify-content-end mb-0 mt-2">
          <li>
            <a class="mx-3" role="button"><i class="fab fa-facebook-f"></i></a>
          </li>
          <li>
            <a class="mx-3" role="button"><i class="fab fa-twitter"></i></a>
          </li>
          <li>
            <a class="mx-3" role="button"><i class="fab fa-instagram"></i></a>
          </li>
        </ul>
      </div>
      
    </div>

  </div>
  <!-- Footer Elements -->

</footer>
<!-- Footer -->
</body>
<script type="text/javascript" src="assets/mdb/js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="assets/bootstrap/js/jquery.js">
  <script type="text/javascript" src="assets/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="assets/mdb/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="assets/bootstrap/js/bootstrap.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="assets/mdb/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
  <script type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
  <script>
      feather.replace()
    </script>
</html>